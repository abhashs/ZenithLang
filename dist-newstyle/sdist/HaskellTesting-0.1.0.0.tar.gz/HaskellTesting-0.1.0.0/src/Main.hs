module Main where

import Text.Megaparsec
import Data.Void
import Data.Text


type MParser = Parsec Void Text

main :: IO ()
main = putStrLn "Hello World"
